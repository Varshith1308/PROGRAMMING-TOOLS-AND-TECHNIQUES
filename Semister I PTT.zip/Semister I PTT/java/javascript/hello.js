		function myFunction() 
		{
			document.getElementById("demo").innerHTML = alert("I am an alert box!");
		}
